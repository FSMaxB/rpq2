Maximale Dateigröße:
<input type="text" name="maxchars" value="1000000000" size="10" maxlength="10">Bytes
