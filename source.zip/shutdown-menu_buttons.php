<button onclick="window.location.href='shutdown.php?status=halt'" style="width:100%">
        <h2 align="center">Herunterfahren</h2>
</button>
<button onclick="window.location.href='shutdown.php?status=reboot'" style="width:100%">
        <h2 align="center">Neustarten</h2>
</button>
