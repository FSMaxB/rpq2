<a href="<?php echo "$ordner/$dateiname";?>"><?php echo $dateiname;?></a>
&ensp;<a href="remove.php?pfad=<?php echo "$ordner/$dateiname";?>&amp;return=<?php echo $return;?>">[Löschen]</a>
&ensp;<a href="submit.php?pfad=<?php echo "$ordner/$dateiname";?>&modus=sollwert">[Übertragen]</a>

<br />
