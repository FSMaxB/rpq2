<?php
$title = 'System herunterfahren';
$author = 'Max Bruckner';

include('header.php');
include('shutdown-menu_buttons.php');
include('footer_sub.php');
?>
