<a href="<?php echo $dateiname;?>"><?php echo $dateiname;?></a>
&ensp;<a href="remove.php?pfad=<?php echo "$ordner/$dateiname";?>&amp;return=<?php echo $return;?>">[Löschen]</a>
<br />
