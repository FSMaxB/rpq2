     <p align="center">
      <button onclick="window.location.href='einstell.php'" style="width:100%">
        <h3 align="center">Zurück zu CSV-Einstellwerte</h3>
      </button>
     </p>
<?php
include('footer.php');
?>
