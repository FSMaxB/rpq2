<?php
$title = 'Steuerung';
$author = 'Max Bruckner';
$heading = 'Steuerung';

include('header.php');
include('heading.php');
echo 'Noch in der Entwicklung!';
include('footer_sub.php');
?>
