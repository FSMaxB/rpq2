     <p align="center">
      <button onclick="window.location.href='regler.php'" style="width:100%">
        <h3 align="center">Zurück zu Regler-Sollwertvorgaben</h3>
      </button>
     </p>
<?php
include('footer.php');
?>
