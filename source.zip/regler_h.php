<?php
$ordner = "regler";		//Ordner in dem die Regler-Sollwertvorgaben gespeichert werden, kann hier global geändert werden
?>
