Maximale Aufnahmedauer:
<select name="maxtime" size="1">
 <option value="10">10s</option>
 <option value="15">15s</option>
 <option value="20">20s</option>
 <option value="30">30s</option>
 <option value="45">45s</option>
 <option value="60">1min</option>
 <option value="120">2min</option>
 <option value="180">3min</option>
 <option value="240">4min</option>
 <option value="300">5min</option>
 <option value="600">10min</option>
 <option value="900">15min</option>
 <option value="1200">20min</option>
 <option value="1800">30min</option>
 <option value="2700">45min</option>
 <option value="3600" selected>1h</option>
 <option value="7200">2h</option>
 <option value="14400">4h</option>
 <option value="28800">8h</option>
 <option value="57600">16h</option>
 <option value="86400">1d</option>
 <option value="172800">2d</option>
 <option value="259200">3d</option>
</select>
